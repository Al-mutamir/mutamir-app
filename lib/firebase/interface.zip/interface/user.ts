// TypeScript interface for a user in the Firebase Firestore database

import type { UserRole } from "@/context/auth-context"

export interface UserData {
  uid: string
  email: string | null
  displayName: string | null
  role: UserRole

  photoURL?: string | null

  createdAt?: Date
  updatedAt?: Date

  onboardingCompleted?: boolean

  phoneNumber?: string

  passportNumber?: string

  countryOfResidence?: string
  cityOfResidence?: string

  age?: number
  gender?: string

  nextOfKin?: string
  nextOfKinPhone?: string
  nextOfKinEmail?: string

  verified?: boolean
}