// TypeScript interface for a booking in the Firebase Firestore database

export interface Booking {
  id: string
  packageId: string
  packageTitle: string
  pilgrimId: string
  agencyId: string
  userEmail: string

  travelDate: Date | string
  returnDate: Date | string

  totalPrice: number

  status:
    | "pending"
    | "confirmed"
    | "cancelled"
    | "completed"

  paymentStatus:
    | "unpaid"
    | "partial"
    | "paid"

  paymentReference?: string

  countryOfResidence?: string
  cityOfResidence?: string
  passportNumber?: string

  highlights?: string[]
  notes?: string
  rating?: number

  createdAt?: any
  updatedAt?: any
}