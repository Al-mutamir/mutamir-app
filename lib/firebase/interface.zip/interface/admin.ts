export interface AdminStats {
  totalUsers: number

  totalAgencies: number

  totalPackages: number

  totalBookings: number

  totalRevenue: number
}

export interface AgencyStats {
  activePackages: number

  totalRevenue: number

  totalClients: number
}

export interface PilgrimStats {
  totalBookings: number

  completedBookings: number

  upcomingBookings: number

  cancelledBookings: number
}